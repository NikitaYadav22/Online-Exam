package com.lti.gladiator.dao;

import com.lti.gladiator.bean.Admin;

public interface AdminDao {
	
	public boolean validateAdmin(Admin admin);
	
}
