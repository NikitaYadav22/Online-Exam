package com.lti.gladiator.service;

import com.lti.gladiator.bean.Admin;


public interface AdminService {

	
	
	public boolean validateAdmin(Admin admin);
}
